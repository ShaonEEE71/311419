#!/usr/bin/env python3

import rospy # Python library for ROS
from sensor_msgs.msg import Image # Image is the message type
from cv_bridge import CvBridge # Package to convert between ROS and OpenCV Images
import cv2 # OpenCV library
import numpy as np 


def publish_message():
 
  pub = rospy.Publisher('image', Image, queue_size=10)

  rospy.init_node('video_pub_py', anonymous=True)

  rate = rospy.Rate(10) # 10hz

  cap1 = cv2.VideoCapture(2)
  cap1.set(3,720)
  cap1.set(4,480)
     
  br1 = CvBridge()
 
  while not rospy.is_shutdown():
      ret, frame = cap1.read()
    
      if ret == True:
        rospy.loginfo('publishing video frame')

        pub.publish(br1.cv2_to_imgmsg(frame,encoding='bgr8'))
             
      # Sleep just enough to maintain the desired rate
      rate.sleep()
         
if __name__ == '__main__':
  try:
    publish_message()
  except rospy.ROSInterruptException:
    pass
